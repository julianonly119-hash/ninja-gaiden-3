# Ninja Gaiden 3: Razor's Edge Launcher — integrated frontend

This is an Android Studio/Kotlin frontend project. It is **not** an Xbox 360 emulator and does not contain Xenia code, firmware, keys, or game files.

## Integration behavior
- Selects and remembers an ISO document URI using Android Storage Access Framework.
- Detects an installed launcher app whose visible name contains `Xendroid` or `Xenia`, then opens it.
- If none is found, opens the Xendroid+ project page.
- It intentionally does not send the ISO through a guessed/undocumented intent. Xendroid+ setup scans a games folder selected from inside its own first-run assistant/library.

## Recommended emulator candidate
Xendroid+ is a current Android Xenia-based Xbox 360 emulator project:
https://phforner0.github.io/Xendroid-Plus/

Follow the emulator's own install and first-run guide. Select/create its game folder and import/scan your own game dump there. Keep the ISO in a folder that the emulator can access. The launcher remembers the selected URI only for display; it does not copy the ISO into the emulator's private storage.

## Device warning — iQOO Z10R 5G Indonesia
The Indonesian iQOO Z10R 5G uses MediaTek Dimensity 7360-Turbo and Mali-G615 MC2. Xendroid+ requires Vulkan and is primarily tuned for Adreno 7xx/8xx with Turnip; its custom Turnip driver path is Adreno-specific. It may open on Mali using the system Vulkan driver, but compatibility/performance are not guaranteed and may be poor. Ninja Gaiden 3: Razor's Edge is not confirmed working on this device.

## Build
1. Open this folder in Android Studio (JDK 17, Android SDK 35).
2. Allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

Application ID: `com.example.ninjagaidenlauncher`

## Notes
- No root permission is required.
- No game ISO is included.
- Only use game backups you are legally entitled to use.
- Xendroid+ is experimental; consult its current docs and compatibility notes before expecting a game to boot.

## One-click cloud build (GitHub Actions)
This project includes `.github/workflows/build-apk.yml`.
1. Create a GitHub repository and upload/push the contents of this project.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and choose **Run workflow**.
4. When it finishes, open the run and download the `NinjaGaiden3RazorEdgeLauncher-debug-apk` artifact.
5. Extract the artifact and install `app-debug.apk` on your Android phone. You may need to allow installation from the browser/file manager.

The generated APK is a debug build. It is installable but not Play Store-signed. The launcher does not include an Xbox 360 emulator.
