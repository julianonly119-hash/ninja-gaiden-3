package com.example.ninjagaidenlauncher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private var selectedIso: Uri? = null
    private lateinit var isoLabel: TextView
    private lateinit var statusLabel: TextView

    companion object { private const val PICK_ISO = 4101 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedIso = prefs.getString("iso_uri", null)?.let(Uri::parse)
        buildUi()
        updateIsoLabel()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(30), dp(22), dp(24))
            setBackgroundColor(0xFF090B10.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scroll.addView(content)

        content.addView(text("XBOX 360 • ANDROID FRONTEND", 12, 0xFFD7A84B.toInt(), true).apply {
            gravity = Gravity.CENTER
        }, matchWrap())

        content.addView(text("NINJA GAIDEN 3", 30, 0xFFF5F1E8.toInt(), true).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.08f
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })

        content.addView(text("RAZOR'S EDGE", 19, 0xFFD7A84B.toInt(), true).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.22f
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        content.addView(View(this).apply { setBackgroundColor(0xFF55452B.toInt()) },
            LinearLayout.LayoutParams(dp(110), dp(2)).apply { topMargin = dp(22); bottomMargin = dp(22) })

        content.addView(text(
            "Pilih ISO milikmu, lalu buka emulator Xbox 360. Untuk Xendroid+, impor/pindai game melalui folder game di dalam emulator.",
            14, 0xFFB8BBC4.toInt(), false
        ).apply { gravity = Gravity.CENTER; setLineSpacing(dp(4).toFloat(), 1f) }, matchWrap())

        isoLabel = text("Belum ada ISO dipilih", 13, 0xFFE5E0D6.toInt(), false).apply {
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(0xFF171B24.toInt())
        }
        content.addView(isoLabel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(26) })

        content.addView(button("PILIH FILE ISO") { pickIso() },
            LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(14) })

        content.addView(button("BUKA EMULATOR XBOX 360") { openXboxEmulator() },
            LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(12) })

        statusLabel = text(
            "Integrasi: membuka aplikasi emulator yang terpasang. Pemindahan/import ISO tetap dilakukan melalui menu emulator.",
            12, 0xFF9CA3AF.toInt(), false
        ).apply { setPadding(2, dp(18), 2, 0); gravity = Gravity.CENTER }
        content.addView(statusLabel, matchWrap())

        content.addView(text(
            "Catatan perangkat\nLauncher ini bukan emulator. Xendroid+ berbasis Xenia dan masih eksperimental. iQOO Z10R 5G Indonesia memakai Dimensity 7360-Turbo dengan GPU Mali-G615 MC2; Xendroid+ menargetkan terutama GPU Adreno/Turnip. Emulator mungkin terpasang tetapi game bisa gagal berjalan atau sangat lambat. Ninja Gaiden 3: Razor's Edge belum terverifikasi kompatibilitasnya pada perangkat ini.",
            12, 0xFF858B98.toInt(), false
        ).apply { setLineSpacing(dp(3).toFloat(), 1f) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(28) })

        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(text("FAN-MADE FRONTEND • NOT AFFILIATED WITH TEAM NINJA OR XBOX",
            9, 0xFF656B76.toInt(), false).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        setContentView(page)
    }

    private fun pickIso() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/x-iso9660-image"))
        }
        startActivityForResult(intent, PICK_ISO)
    }

    @Deprecated("Uses activity result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_ISO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { }
            selectedIso = uri
            prefs.edit().putString("iso_uri", uri.toString()).apply()
            updateIsoLabel()
            statusLabel.text = "ISO tersimpan di launcher. Buka emulator dan pilih folder yang berisi ISO melalui setup/library emulator."
        }
    }

    private fun updateIsoLabel() {
        isoLabel.text = selectedIso?.let { "ISO DIPILIH\n${it.lastPathSegment ?: it}" } ?: "Belum ada ISO dipilih"
    }

    private fun openXboxEmulator() {
        // Avoid hard-coding an undocumented package name. Find a launchable installed app
        // whose visible label contains Xendroid or Xenia.
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = packageManager.queryIntentActivities(launcherIntent, 0)
        val target = matches.firstOrNull {
            val label = it.loadLabel(packageManager).toString()
            label.contains("xendroid", ignoreCase = true) || label.contains("xenia", ignoreCase = true)
        }

        if (target != null) {
            val packageName = target.activityInfo.packageName
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                startActivity(launch)
                statusLabel.text = "Emulator dibuka. Impor/pindai folder ISO dari dalam emulator."
                return
            }
        }

        statusLabel.text = "Xendroid/Xenia tidak ditemukan. Pasang emulator kompatibel terlebih dahulu, lalu buka tombol ini lagi."
        Toast.makeText(this, "Emulator Xbox 360 belum ditemukan.", Toast.LENGTH_LONG).show()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://phforner0.github.io/Xendroid-Plus/")))
        } catch (_: ActivityNotFoundException) { }
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 14f; isAllCaps = false
        setTextColor(0xFF101116.toInt())
        setBackgroundColor(0xFFD7A84B.toInt())
        setOnClickListener { action() }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
